import javafx.geometry.Insets;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleButton;
import javafx.scene.image.Image;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundImage;
import javafx.scene.layout.BackgroundSize;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;

public class AddShopPass {
	private Label addShopLabel = new Label("Enter The Admin Password : ");
	private PasswordField shopaddpass = new PasswordField();
	public PasswordField getShopaddpass() {
		return shopaddpass;
	}


	public void setShopaddpass(PasswordField shopaddpass) {
		this.shopaddpass = shopaddpass;
	}

	private Button addShopOkButton = new Button("OK");
	private Button cancel = new Button("Cancel");
	private ToggleButton show = new ToggleButton(" Show ");
	private GridPane addShopPane = new GridPane();
	String cellStyle = "-fx-control-inner-background: darkblue; -fx-table-cell-border-color: black;-fx-table-cell-border-color: darkturquoise;";
	String style = "-fx-background-radius: 10em; " + "-fx-min-width: 150px; " + "-fx-min-height: 15px; "
			+ "-fx-max-width: 150px; " + "-fx-max-height: 40px; " + "-fx-background-color: darkturquoise;";

	AddShopPass() {

		// Create labels, text fields, and an "OK" button
		addShopLabel.setFont(Font.font(20));
		addShopLabel.setTextFill(Color.BLACK);

		addShopOkButton.setStyle(style);
		cancel.setStyle(style);
		show.setStyle(style);
		// Create the additional pane (GridPane) for removing a shop
		addShopPane.addRow(0, addShopLabel, shopaddpass,show);
		addShopPane.add(addShopOkButton, 0, 1, 2, 1);
		
		addShopPane.add(cancel, 1, 1, 2, 1);

		// Apply styling to the additional pane for removing a shop
//		upShopPane.setStyle("-fx-background-color: black; " + "-fx-text-fill: white; ");
		Image backgroundImage = new Image("shop.jpeg");
		BackgroundSize backgroundSize = new BackgroundSize(400, 250, false, false, false, false);
		BackgroundImage background = new BackgroundImage(backgroundImage, null, null, null, backgroundSize);

		addShopPane.setBackground(new Background(background));

		// Set padding and spacing
		addShopPane.setPadding(new Insets(10));
		addShopPane.setHgap(10);
		addShopPane.setVgap(10);

	}
	

	public ToggleButton getShow() {
		return show;
	}


	public void setShow(ToggleButton show) {
		this.show = show;
	}


	public Label getAddShopLabel() {
		return addShopLabel;
	}

	

	public Button getAddShopOkButton() {
		return addShopOkButton;
	}

	public Button getCancel() {
		return cancel;
	}

	public GridPane getAddShopPane() {
		return addShopPane;
	}

	public String getCellStyle() {
		return cellStyle;
	}

	public String getStyle() {
		return style;
	}

	public void setAddShopLabel(Label addShopLabel) {
		this.addShopLabel = addShopLabel;
	}

	

	public void setAddShopOkButton(Button addShopOkButton) {
		this.addShopOkButton = addShopOkButton;
	}

	public void setCancel(Button cancel) {
		this.cancel = cancel;
	}

	public void setAddShopPane(GridPane addShopPane) {
		this.addShopPane = addShopPane;
	}

	public void setCellStyle(String cellStyle) {
		this.cellStyle = cellStyle;
	}

	public void setStyle(String style) {
		this.style = style;
	}
	

	
}
