import javafx.beans.property.SimpleDoubleProperty;

import javafx.beans.property.SimpleStringProperty;

public class BuysTable {
	private SimpleStringProperty custname ;
	private SimpleStringProperty custid;
	private SimpleStringProperty sellid;
	private SimpleStringProperty serialnum;
	private SimpleStringProperty sellname;
	private SimpleStringProperty model;
	private SimpleDoubleProperty price;
	
	
	public BuysTable(String custname, String custid, String sellid, String serialnum, String sellname, String model, double price) {
        this.custname = new SimpleStringProperty(custname);
        this.custid = new SimpleStringProperty(custid);
        this.sellid = new SimpleStringProperty(sellid);
        this.serialnum = new SimpleStringProperty(serialnum);
        this.sellname = new SimpleStringProperty(sellname);
        this.model = new SimpleStringProperty(model);
        this.price = new SimpleDoubleProperty(price);
    }

    // Getters
    public String getCustname() {
        return custname.get();
    }

    public String getCustid() {
        return custid.get();
    }

    public String getSellid() {
        return sellid.get();
    }

    public String getSerialnum() {
        return serialnum.get();
    }

    public String getSellname() {
        return sellname.get();
    }

    public String getModel() {
        return model.get();
    }

    public double getPrice() {
        return price.get();
    }

    // Setters
    public void setCustname(String custname) {
        this.custname.set(custname);
    }

    public void setCustid(String custid) {
        this.custid.set(custid);
    }

    public void setSellid(String sellid) {
        this.sellid.set(sellid);
    }

    public void setSerialnum(String serialnum) {
        this.serialnum.set(serialnum);
    }

    public void setSellname(String sellname) {
        this.sellname.set(sellname);
    }

    public void setModel(String model) {
        this.model.set(model);
    }

    public void setPrice(double price) {
        this.price.set(price);
    }

}
