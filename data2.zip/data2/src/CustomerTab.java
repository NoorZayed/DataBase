
import javafx.scene.control.Tab;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.VBox;

public class CustomerTab {
    private TableView<CustomerTable> customerTableView;
    private TableColumn<CustomerTable, String> customerNameColumn = new TableColumn<>("Customer Name");
    private TableColumn<CustomerTable, String> customerAddressColumn = new TableColumn<>("Address");
    private TableColumn<CustomerTable, String> customerIdColumn = new TableColumn<>("Customer ID");
    private TableColumn<CustomerTable, String> customerPhoneColumn = new TableColumn<>("Customer Phone");
    private TableColumn<CustomerTable, String> customerPasswordColumn = new TableColumn<>("Customer Password");
    private VBox vbox;
    private Tab customerTab = new Tab("Customer");

    String cellStyle = "-fx-control-inner-background: darkblue; -fx-table-cell-border-color: black;-fx-table-cell-border-color: darkturquoise;";

    CustomerTab() {
        // Create TableView and columns for customers
        customerTableView = new TableView<>();

        customerNameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));
        customerAddressColumn.setCellValueFactory(new PropertyValueFactory<>("address"));
        customerIdColumn.setCellValueFactory(new PropertyValueFactory<>("custid"));
        customerPhoneColumn.setCellValueFactory(new PropertyValueFactory<>("phonenum"));
        customerPasswordColumn.setCellValueFactory(new PropertyValueFactory<>("password"));

        customerTableView.getColumns().addAll(customerNameColumn, customerAddressColumn, customerIdColumn,
                customerPhoneColumn, customerPasswordColumn);

        // Apply styling to the TableView
        customerTableView.setStyle(cellStyle);
        customerTableView.setSelectionModel(null);
        // Set preferred widths for each column
        customerNameColumn.setPrefWidth(150); // Adjust as needed
        customerIdColumn.setPrefWidth(120);
        customerPhoneColumn.setPrefWidth(150);
        customerPasswordColumn.setPrefWidth(150);
        // Apply styling to the TableView columns
//        for (TableColumn<CustomerTable, ?> column : customerTableView.getColumns()) {
//            column.setStyle("-fx-background-color: white; -fx-text-fill: white;");
//        }

        // Create a VBox to hold the customer TableView
        vbox = new VBox(customerTableView);
        vbox.setSpacing(15);

        // Create a Tab and set its content
        customerTab.setContent(vbox);
    }

	public TableView<CustomerTable> getCustomerTableView() {
		return customerTableView;
	}

	public void setCustomerTableView(TableView<CustomerTable> customerTableView) {
		this.customerTableView = customerTableView;
	}

	public TableColumn<CustomerTable, String> getCustomerNameColumn() {
		return customerNameColumn;
	}

	public void setCustomerNameColumn(TableColumn<CustomerTable, String> customerNameColumn) {
		this.customerNameColumn = customerNameColumn;
	}

	public TableColumn<CustomerTable, String> getCustomerAddressColumn() {
		return customerAddressColumn;
	}

	public void setCustomerAddressColumn(TableColumn<CustomerTable, String> customerAddressColumn) {
		this.customerAddressColumn = customerAddressColumn;
	}

	public TableColumn<CustomerTable, String> getCustomerIdColumn() {
		return customerIdColumn;
	}

	public void setCustomerIdColumn(TableColumn<CustomerTable, String> customerIdColumn) {
		this.customerIdColumn = customerIdColumn;
	}

	public TableColumn<CustomerTable, String> getCustomerPhoneColumn() {
		return customerPhoneColumn;
	}

	public void setCustomerPhoneColumn(TableColumn<CustomerTable, String> customerPhoneColumn) {
		this.customerPhoneColumn = customerPhoneColumn;
	}

	public TableColumn<CustomerTable, String> getCustomerPasswordColumn() {
		return customerPasswordColumn;
	}

	public void setCustomerPasswordColumn(TableColumn<CustomerTable, String> customerPasswordColumn) {
		this.customerPasswordColumn = customerPasswordColumn;
	}

	public VBox getVbox() {
		return vbox;
	}

	public void setVbox(VBox vbox) {
		this.vbox = vbox;
	}

	public Tab getCustomerTab() {
		return customerTab;
	}

	public void setCustomerTab(Tab customerTab) {
		this.customerTab = customerTab;
	}

	public String getCellStyle() {
		return cellStyle;
	}

	public void setCellStyle(String cellStyle) {
		this.cellStyle = cellStyle;
	}

}

